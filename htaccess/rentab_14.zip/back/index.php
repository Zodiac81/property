<?php
header('Content-Type: text/html; charset=utf-8');
session_start();

// Конфиг сайта
require_once __DIR__ . '/config.php';
require_once '../libs/route.php';


if(isset($_GET['_route_'])){
    $path = my_rout_admin($_GET['_route_']);
    if($path == 404){
        $add_controller = 'errors/404';
    }
    else{
        $path_mass = explode('/', $path);
        $get_path = array();
        foreach ($path_mass as $pm) {
            $small_path = explode('=', $pm);
            if($small_path[0] == 'controller'){
                $add_controller =  $small_path[1];
            }
            else{
                $get_path[$small_path[0]] = $small_path[1];
            }

        }
    }
}
else{
    $add_controller = 'main';
}
    //подключим нужные контроллеры
    include DIR_ROOT . '/controller/header.php';
    include DIR_ROOT . '/controller/'.$add_controller.'.php';
    include DIR_ROOT . '/controller/footer.php';

    include VIEW.'header.tpl';
    include VIEW.$add_controller.'.tpl';
    include VIEW.'footer.tpl';  

// Роутер
//include './modules/'.$_GET['module'].'/'.$_GET['page'].'.php';
//include './skins/'.SKIN.'/index.tpl';
