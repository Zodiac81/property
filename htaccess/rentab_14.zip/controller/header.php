<?php
include '/model/header.php';
$title = 'Тестовый единый title';
$key = 'Тестовый единый key';
$desc = 'Тестовый единый desc';
