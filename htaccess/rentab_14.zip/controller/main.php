<?php
$maintext = 'Текст главной !!!';


