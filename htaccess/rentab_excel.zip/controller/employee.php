<?php
require_once '/model/employee.php';

/* !!!!!!!!!!!!!!!!!!!!!!!!   Часть контроллера только для AJAX обращений   !!!!!!!!!!!!!!!!!!!!!!!!!!! */
if(isset($_REQUEST['metod']) && $_REQUEST['metod']=='ajax'){
	
	//удалим сотрудника из БД
	if(isset($_GET['iddell'])){
		echo delEmployee($_GET['iddell'])?true:false;
	}
	
	//изменим зп/час для конкретного пользователя для кокретного месяца
	if(isset($_POST['zp'])){
		echo updateEmployeeZP($_POST['emp_id'],$_POST['month'],$_POST['year'],$_POST['zp']);
	}
	if(isset($_POST['zp_mif'])){
		echo updateEmployeeZPmif($_POST['emp_id'],$_POST['zp_mif']);
	}	

}
/* !!!!!!!!!!!!!!!!!!!!!   КОНЕЦ Части контроллера только для AJAX обращений   !!!!!!!!!!!!!!!!!!!!!!!! */

/* !!!!!!!!!!!!!!!!!!!!!!!!   Для SEO   !!!!!!!!!!!!!!!!!!!!!!!!!!! */
$seo_title = 'Сотрудники компании ART-Lemon';
/* !!!!!!!!!!!!!!!!!!   КОНЕЦ Части для SEO   !!!!!!!!!!!!!!!!!!!!! */


$allmonth = allMonth();
$allyear = allYear();

$month = $_GET['date_month']?$_GET['date_month']:(int)date('m');
$year = $_GET['date_year']?$_GET['date_year']:(int)date('Y');
$mass_employee = getEmployee($month,$year);

	



