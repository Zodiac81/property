<?php
include '/model/header.php';
$seo_title = 'Тестовый единый title';
$seo_key = 'Тестовый единый key';
$seo_desc = 'Тестовый единый desc';
