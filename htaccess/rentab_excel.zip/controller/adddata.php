<?php
include '/model/adddata.php';

/* !!!!!!!!!!!!!!!!!!!!!!!!   Часть контроллера только для AJAX обращений   !!!!!!!!!!!!!!!!!!!!!!!!!!! */
if(isset($_REQUEST['metod']) && $_REQUEST['metod']=='ajax'){
	
	//удалим сотрудника из БД
	if(isset($_GET['getdataproj'])){
		$id_proj = $_GET['getdataproj'];
		$mass_data_proj = getDataProject($id_proj);
		print_r( json_encode($mass_data_proj));
	}
}
/* !!!!!!!!!!!!!!!!!!!!!   КОНЕЦ Части контроллера только для AJAX обращений   !!!!!!!!!!!!!!!!!!!!!!!! */


/* !!!!!!!!!!!!!!!!!!!!!!!!   Для SEO   !!!!!!!!!!!!!!!!!!!!!!!!!!! */
$seo_title = 'Добавление данных';
/* !!!!!!!!!!!!!!!!!!   КОНЕЦ Части для SEO   !!!!!!!!!!!!!!!!!!!!! */



$valid_types = array("xls", "xlsx");

if (isset($_FILES["userfile"])) {
		$selector_file_is_here - false;
		if (is_uploaded_file($_FILES['userfile']['tmp_name'])) {
				$filename=basename($_FILES['userfile']['name']);
				$ext = substr($_FILES['userfile']['name'], 1 + strrpos($_FILES['userfile']['name'], "."));
				if(in_array($ext, $valid_types)){
						$uploaddir = DIR_ROOT . '/uploads/';
						$uploadfile = $uploaddir.$filename;
						move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile);
						$selector_file_is_here = 1;
				}
				else{
					$error = 'Error: bed type of file'; 
				}
		}
		else { $error = "Error: empty file.";}

		//тут пишем логику разбора в базу данных
		if($selector_file_is_here){
			
			$project_name = ($_POST['optionsRadios'] == 'oldpr')?projName($_POST['oldprojectid']):$_POST['project_name'];
			$date_start = $_POST['date_start'];
			$date_finish = $_POST['date_finish'];
			$count_price = $_POST['count_price'];
			
			//если проекта нет, то он добавится. Если есть - изменится:
			$id_proj = addProject($project_name, $date_start, $date_finish, $count_price);

			
			
			require_once(LIBS . 'PHPExcel/Classes/PHPExcel/IOFactory.php');
			
			$xls = PHPExcel_IOFactory::load($uploadfile);
			$xls->setActiveSheetIndex(0);
			$sheet = $xls->getActiveSheet();

			// Получили строки и обойдем их в цикле
			$rowIterator = $sheet->getRowIterator();
			
			$stroka = 0;
			$mass_report = array();
			foreach ($rowIterator as $row) {
				// Получили ячейки текущей строки и обойдем их в цикле
				if($stroka!=0){
									$cellIterator = $row->getCellIterator();
									$stolbec = 0;
									foreach ($cellIterator as $cell) {
										if($stolbec==0){
											$date = $cell->getCalculatedValue();
											if(PHPExcel_Shared_Date::isDateTime($cell)) {
												 $date = date("Y-m-d", PHPExcel_Shared_Date::ExcelToPHP($date)); 
											}														
										}
										elseif($stolbec==5){
											$who = $cell->getCalculatedValue();
										}
										elseif($stolbec==8){
											$time = $cell->getCalculatedValue();
										}
										$stolbec++;
									}
									$mass_report[] = array(
										'date_work' => $date,
										'employee'  => $who,
										'time_work' => $time
									);
								
				}
				$stroka++;
			}			

			//сначала удалим старые данные в таблице report
			delReports($id_proj);
			//разберем массив и положим в базу данных
			foreach ($mass_report as $value) {
				insertReport($id_proj, $value['date_work'], $value['employee'], $value['time_work']);
			}
		}
} 

//кусок кода по обработке массива репорта - пока возмем из базы...
//$mass_report = getMassReport();

//получим перечень проектов для tpl
$mass_all_project = getAllProject();