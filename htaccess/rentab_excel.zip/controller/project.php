<?php
require_once '/model/project.php';

/* !!!!!!!!!!!!!!!!!!!!!!!!   Часть контроллера только для AJAX обращений   !!!!!!!!!!!!!!!!!!!!!!!!!!! */
if(isset($_REQUEST['metod']) && $_REQUEST['metod']=='ajax'){
	
	$ajax = '';
}
/* !!!!!!!!!!!!!!!!!!!!!   КОНЕЦ Части контроллера только для AJAX обращений   !!!!!!!!!!!!!!!!!!!!!!!! */

if(isset($_GET['id_project'])){
	$id = $_GET['id_project'];
}
else{
	header("Location:http://rentab/projects");
}
$mass_project = getProjectById($id);


/* !!!!!!!!!!!!!!!!!!!!!!!!   Для SEO   !!!!!!!!!!!!!!!!!!!!!!!!!!! */
$seo_title = $mass_project['name'];
/* !!!!!!!!!!!!!!!!!!   КОНЕЦ Части для SEO   !!!!!!!!!!!!!!!!!!!!! */

//Получаю весь массив данных затрат времени сотрудников по проекту
$res = getAllTimeByProject($id);
if($res){
	header("Location:http://rentab/projects");
}
else{
	echo 'Ошибка: не получилось расчитать рентабельность проекта';
}


