<?php
include '/model/footer.php';
mysqli_close($db);