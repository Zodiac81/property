<?php

$model_name = 'projects';

function getProjects(){
		global $db;

		$query_proj = "SELECT * FROM project;";
		$result_proj = mysqli_query($db, $query_proj) or die("Ошибка " . mysqli_error($db));
		
		if($result_proj){
			while ($row = mysqli_fetch_assoc($result_proj)) {
					$mass_return[] = array(
						'id_proj' => $row['id_proj'],
						'name' => $row['name'],
						'date_start' => $row['date_start'],
						'date_finish' => $row['date_finish'],
						'total_price' => $row['total_price'],
						'total_zp' => $row['total_zp'],
						'total_mif' => $row['total_mif'],
						'rentab' => $row['rentab'],
						'rentab_mif' => $row['rentab_mif'],
						'date_excel' => $row['date_excel']
					);
			}			
		}		
		return $mass_return;

}

