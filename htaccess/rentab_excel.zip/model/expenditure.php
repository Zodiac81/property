<?php
$model_name = 'expenditure';

function getExpenditure($month,$year){
		global $db;
		$mass_return = array();
		$query_employee = "SELECT * FROM global_settings";
		$result_employee = mysqli_query($db, $query_employee) or die("Ошибка " . mysqli_error($db));

		if($result_employee){
			while ($row = mysqli_fetch_assoc($result_employee)) { 
					$id_gs = $row['id_gs'];
				
					//подзапрос для получения зп за текщий месяц
					$query_zpm = "SELECT value FROM global_settings_month_param WHERE id_gs='$id_gs' AND month='$month' AND year='$year'";
					$result_zpm = mysqli_query($db, $query_zpm) or die("Ошибка " . mysqli_error($db));	
					$row_zpm = mysqli_fetch_assoc($result_zpm);
				
					$mass_return[] = array(
						'id_gs' => $id_gs,
						'name' => $row['name'],
						'value' => $row_zpm['value']?$row_zpm['value']:0,
						'status' => $row['status']
					);
			}			
		}		
		return $mass_return;	
}

function updateExpenditureValue($id_gs,$month,$year,$value){
		global $db;
		
		//проверим а есть ли такая запись если нет - INSERT иначе UPDATE
		$query_test = "SELECT value FROM global_settings_month_param WHERE id_gs='$id_gs' AND month='$month' AND year='$year';";
		$result_test = mysqli_query($db, $query_test) or die("Ошибка " . mysqli_error($db));

		if($result_test->num_rows > 0){
				$query_update ="UPDATE global_settings_month_param SET value='$value' WHERE id_gs='$id_gs' AND month='$month' AND year='$year';";
				if(mysqli_query($db, $query_update)){
					return true;
				}
				else{
					return false;
				}
		}
		else{
				$query ="INSERT INTO global_settings_month_param  (`id_gs`,`month`,`year`,`value`) VALUES ($id_gs,$month,$year,$value);";
				if(mysqli_query($db, $query)){
					return mysqli_insert_id($db);
				}
				else{
					return FALSE;
				}	
		}
}