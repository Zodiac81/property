<?php

$model_name = 'project';

function getProjectById($id) {
		global $db;
		
		$query_proj = "SELECT * FROM project;";
		$result_proj = mysqli_query($db, $query_proj) or die("Ошибка " . mysqli_error($db));
		
		if($result_proj){
			while ($row = mysqli_fetch_assoc($result_proj)) {
					$mass_return = array(
						'id_proj' => $row['id_proj'],
						'name' => $row['name'],
						'date_start' => $row['date_start'],
						'date_finish' => $row['date_finish'],
						'total_price' => $row['total_price']
					);
			}			
		}		
		return $mass_return;
}

function getEmployeeByName($name){
		
		global $db;
		
		$query = "SELECT id_emp FROM employee WHERE name = '$name';";
		$result = mysqli_query($db, $query) or die("Ошибка " . mysqli_error($db));
		if($result){
			$row = mysqli_fetch_assoc($result);
			return $row['id_emp'];
		}
		else{
			return null;
		}
}

function getEmployeeZp($y,$m,$id){
		
		global $db;
		
		$query = "SELECT zp_time FROM employee_month_param WHERE id_emp = '$id' AND year = '$y' AND month = '$m';";
		$result = mysqli_query($db, $query) or die("Ошибка " . mysqli_error($db));
		if($result){
			$row = mysqli_fetch_assoc($result);
			return $row['zp_time'];
		}
		else{
			return null;
		}
}

function getEmployeeZpMif($id_emp){
		global $db;
		
		$query = "SELECT zp_mif FROM employee WHERE id_emp = '$id_emp';";
		$result = mysqli_query($db, $query) or die("Ошибка " . mysqli_error($db));
		if($result){
			$row = mysqli_fetch_assoc($result);
			return $row['zp_mif'];
		}
		else{
			return null;
		}
}

function getTotalPriceProject($id_project){
		
		global $db;
		
		$query = "SELECT total_price FROM project WHERE id_proj = '$id_project';";
		$result = mysqli_query($db, $query) or die("Ошибка " . mysqli_error($db));
		if($result){
			$row = mysqli_fetch_assoc($result);
			return $row['total_price'];
		}
		else{
			return null;
		}
}

function getTotlaZtr($y,$m){
	
	global $db;	
	$tot_sum = 0;
	$tot_our = 1;
	
	$query = "SELECT id_gs, value FROM global_settings_month_param WHERE year = '$y' AND month = '$m';";
	$result = mysqli_query($db, $query) or die("Ошибка " . mysqli_error($db));
	if($result){
			while ($row = mysqli_fetch_assoc($result)) {
					if($row['id_gs'] == 1){
						$tot_sum = $row['value'];
					}
					if($row['id_gs'] == 2){
						$tot_our = $row['value'];
					}
			}
	}
	return $tot_sum/$tot_our;
}

function getAllTimeByProject($id_project){
	
		global $db;
		
		$query_proj = "SELECT * FROM report WHERE id_project = '$id_project';";
		$result_proj = mysqli_query($db, $query_proj) or die("Ошибка " . mysqli_error($db));
		$mass_answer = array();
		$summa = 0;
		$summa_mif = 0;
		
		if($result_proj){
			while ($row = mysqli_fetch_assoc($result_proj)) {
				//достать из date_work месяц и год 

				$date_work = explode('-',$row['date_work']);
				$date_y = $date_work[0];
				$date_m = $date_work[1];
				$employee_id = getEmployeeByName($row['employee']);
				if(!$employee_id){ break; }
				//получим сколько стоит час сотрудника
				$zp = getEmployeeZp($date_y, $date_m, $employee_id);
				$zp_mif = getEmployeeZpMif($employee_id);
				//плюс получим расклад общих затрат на час сотрудника
				$total_ztr = getTotlaZtr($date_y, $date_m); 
				$zp +=$total_ztr;
				$zp_mif +=$total_ztr;
				$summa += $zp * $row['time_work'];
				$summa_mif += $zp_mif * $row['time_work'];
			}			
		}		
		//в summa у нас общая затрата на ЗП сотрудников по проекту
		//но нам нужно так же посчитать рентабельность
		$rentab = getTotalPriceProject($id_project) - $summa;
		$rentab_mif = getTotalPriceProject($id_project) - $summa_mif;
		//обновим запись в project
		$query_update ="UPDATE project SET total_zp='$summa', total_mif='$summa_mif', rentab='$rentab', rentab_mif='$rentab_mif' WHERE id_proj='$id_project'";
		mysqli_query($db, $query_update) or die("Ошибка " . mysqli_error($db));
		
		$mass_answer = array(
			'zp_project'=>$summa,
			'rentab'=>$rentab,
			'zp_project_mif'=>$summa_mif,
			'rentab_mif'=>$rentab_mif,			
		);
		
		return $summa;	
}

