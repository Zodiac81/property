<?php
$model_name = 'employee';


function getEmployee($month,$year) {
		global $db;
		$mass_return = array();
		$query_employee = "SELECT * FROM employee";
		$result_employee = mysqli_query($db, $query_employee) or die("Ошибка " . mysqli_error($db));

		if($result_employee){
			while ($row = mysqli_fetch_assoc($result_employee)) {
					$id_emp = $row['id_emp'];
				
					//подзапрос для получения зп за текщий месяц
					$query_zpm = "SELECT zp_time FROM employee_month_param WHERE id_emp='$id_emp' AND month='$month' AND year='$year'";
					$result_zpm = mysqli_query($db, $query_zpm) or die("Ошибка " . mysqli_error($db));	
					$row_zpm = mysqli_fetch_assoc($result_zpm);
				
					$mass_return[] = array(
						'id_emp' => $id_emp,
						'name' => $row['name'],
						'zp_time' => $row_zpm['zp_time']?$row_zpm['zp_time']:0,
						'status' => $row['status'],
						'zp_mif' => $row['zp_mif']
					);
			}			
		}		
		return $mass_return;
}

function delEmployee($iddell){
		global $db;
		$query ="DELETE FROM employee WHERE id_emp = '$iddell';";
		if(mysqli_query($db, $query)){
			return TRUE;
		}
		else{
			return FALSE;
		}
}

function updateEmployeeZP($emp_id,$month,$year,$zp){
		global $db;
		
		//проверим а есть ли такая запись если нет - INSERT иначе UPDATE
		$query_test = "SELECT zp_time FROM employee_month_param WHERE id_emp='$emp_id' AND month='$month' AND year='$year';";
		$result_test = mysqli_query($db, $query_test) or die("Ошибка " . mysqli_error($db));

		if($result_test->num_rows > 0){
				$query_update ="UPDATE employee_month_param SET zp_time='$zp' WHERE id_emp='$emp_id' AND month='$month' AND year='$year';";
				if(mysqli_query($db, $query_update)){
					return true;
				}
				else{
					return false;
				}
		}
		else{
				$query ="INSERT INTO employee_month_param  (`id_emp`,`month`,`year`,`zp_time`) VALUES ($emp_id,$month,$year,$zp);";
				if(mysqli_query($db, $query)){
					return mysqli_insert_id($db);
				}
				else{
					return FALSE;
				}	
		}
}

function updateEmployeeZPmif($emp_id,$zp_mif){
	
		global $db;

		$query_update ="UPDATE employee SET zp_mif='$zp_mif' WHERE id_emp='$emp_id';";
		if(mysqli_query($db, $query_update)){
			return true;
		}
		else{
			return false;
		}
}