<?php
function insertReport($id_project, $date_work, $employee, $time_work){
		global $db;
		
		//проверим есть ли такой сотрудник и если нет - создадим
		$query_employee = "SELECT id_emp FROM employee WHERE name = '$employee'";
		$result_employee = mysqli_query($db, $query_employee) or die("Ошибка " . mysqli_error($db));
		$row = mysqli_fetch_assoc($result_employee);
		if(!$row['id_emp']){
			$query_employee_add ="INSERT INTO employee (`name`) VALUES ('$employee');";
			mysqli_query($db, $query_employee_add);
		}	
		
		$query ="INSERT INTO report (`id_project`, `date_work`, `employee`, `time_work`) VALUES ('$id_project', '$date_work', '$employee', '$time_work');";
		if(mysqli_query($db, $query)){
			return TRUE;
		}
		else{
			return FALSE;
		}		

}

function getAllProject(){
		global $db;
		$query_employee = "SELECT id_proj, name FROM project";
		$result_employee = mysqli_query($db, $query_employee) or die("Ошибка " . mysqli_error($db));
		return $result_employee;
}

function projName($id){
		global $db;	
		$query = "SELECT name FROM project WHERE id_proj = '$id'";
		$result = mysqli_query($db, $query) or die("Ошибка " . mysqli_error($db));
		$row = mysqli_fetch_assoc($result);
		return $row['name'];

}

function getDataProject($id_proj){
		global $db;

		$query_proj = "SELECT * FROM project WHERE id_proj = '$id_proj';";
		$result_proj = mysqli_query($db, $query_proj) or die("Ошибка " . mysqli_error($db));
		
		if($result_proj){
			while ($row = mysqli_fetch_assoc($result_proj)) {
					$mass_return = array(
						'name' => $row['name'],
						'date_start' => $row['date_start'],
						'date_finish' => $row['date_finish'],
						'total_price' => $row['total_price']
					);
			}			
		}		
		return $mass_return;

}

function addProject($project_name, $date_start, $date_finish, $count_price){
		global $db;
		//проверм нет ли такого (на всякий случай)
		$query_control = "SELECT * FROM project WHERE name = '$project_name';";
		$result_control = mysqli_query($db, $query_control) or die("Ошибка " . mysqli_error($db));
		if($result_control->num_rows > 0 ){
			
			$row = mysqli_fetch_assoc($result_control);
			$id_proj = $row['id_proj'];
			//такой проект есть и мы сделаем update на случай если что-то изменилось
			$query_update ="UPDATE project SET name='$project_name', date_start='$date_start', date_finish='$date_finish', total_price='$count_price', date_excel=NOW() WHERE id_proj='$id_proj'";
			mysqli_query($db, $query_update) or die("Ошибка " . mysqli_error($db));
			
			return $id_proj;
		}
		else{
			//такого проекта нет - значит добавим
			$query ="INSERT INTO project (`name`, `date_start`, `date_finish`, `total_price`, `date_excel`) VALUES ('$project_name', '$date_start', '$date_finish', '$count_price', NOW());";
			if(mysqli_query($db, $query)){
				return mysqli_insert_id($db);
			}
			else{
				return FALSE;
			}		
		}
		
}

function delReport($id_report){
		global $db;
		$query ="DELETE FROM report WHERE id_report = '$id_report';";
		if(mysqli_query($db, $query)){
			return TRUE;
		}
		else{
			return FALSE;
		}	
}
function delReports($id_project){
		global $db;
		$query ="DELETE FROM report WHERE id_project = '$id_project';";
		if(mysqli_query($db, $query)){
			return TRUE;
		}
		else{
			return FALSE;
		}	
}