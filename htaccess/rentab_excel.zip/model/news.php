<?php
//echo '<pre>'; print_r('А это модель news'); echo '</pre>';

