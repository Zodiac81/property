<?php
$model = 'footer';

