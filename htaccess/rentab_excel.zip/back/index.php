<?php
header('Content-Type: text/html; charset=utf-8');
session_start();

// Конфиг сайта
require_once __DIR__ . '/config.php';
require_once '../libs/route.php';
require_once '../libs/default.php';


if(isset($_GET['_route_'])){
    $path = my_rout_admin($_GET['_route_']);
    if($path == 404){
        $add_controller = 'errors/404';
    }
    else{
        $path_mass = explode('/', $path);
        $get_path = array();
        foreach ($path_mass as $pm) {
            $small_path = explode('=', $pm);
            if($small_path[0] == 'controller'){
                $add_controller =  $small_path[1];
            }
            else{
                $get_path[$small_path[0]] = $small_path[1];
            }

        }
    }
}
else{
    $add_controller = 'main';
}

if(isset($_REQUEST['metod']) && $_REQUEST['metod']=='ajax'){
	//если AJAX - то подключаем только контроллер
	require_once DIR_ROOT . '/controller/'.$add_controller.'.php';
}
else{
	//подключим нужные контроллеры
	require_once DIR_ROOT . '/controller/header.php';
	require_once DIR_ROOT . '/controller/'.$add_controller.'.php';
	require_once DIR_ROOT . '/controller/footer.php';
	//подключим верстку
    require_once VIEW.'header.tpl';
    require_once VIEW.$add_controller.'.tpl';
    require_once VIEW.'footer.tpl';  
}


// Роутер
//include './modules/'.$_GET['module'].'/'.$_GET['page'].'.php';
//include './skins/'.SKIN.'/index.tpl';
