<?php
$host = 'localhost'; 		// адрес сервера 
$database = 'rentab';            // имя базы данных
$user = 'root'; 		// имя пользователя
$password = ''; 		// пароль

$db = mysqli_connect($host, $user, $password, $database) or die("Ошибка " . mysqli_error($db));

//Основные константы
define('DIR_ROOT', __DIR__ . '/');
define('VIEW', DIR_ROOT .'view/default/');

?>