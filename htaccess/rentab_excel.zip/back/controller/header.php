<?php
include DIR_ROOT . 'model/header.php';
$title = 'Тестовый единый title ADMIN';
$key = 'Тестовый единый key ADMIN';
$desc = 'Тестовый единый desc ADMIN';
