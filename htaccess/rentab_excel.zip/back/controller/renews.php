<?php

$text_controller = 'Тут текст контролера RENEWS';
