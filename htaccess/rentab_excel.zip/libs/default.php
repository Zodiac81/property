<?php
function allMonth(){
	$month = array(
		'1'=>'Январь',
		'2'=>'Февраль',
		'3'=>'Март',
		'4'=>'Апрель',
		'5'=>'Май',
		'6'=>'Июнь',
		'7'=>'Июль',
		'8'=>'Август',
		'9'=>'Сентябрь',
		'10'=>'Октябрь',
		'11'=>'Ноябрь',
		'12'=>'Декабрь'
	);
	return $month;
}

function allYear(){
	$mass = array();
	$year_now = (int)date('Y');
	for($i=2015; $i<=$year_now; $i++){
		array_push($mass,$i);
	}
	return $mass;
}

