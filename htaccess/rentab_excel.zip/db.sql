-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.45 - MySQL Community Server (GPL)
-- ОС Сервера:                   Win32
-- HeidiSQL Версия:              9.2.0.4961
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица mycms.url_alias
DROP TABLE IF EXISTS `url_alias`;
CREATE TABLE IF NOT EXISTS `url_alias` (
  `id_url_alias` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(250) NOT NULL,
  `alias` varchar(250) NOT NULL,
  PRIMARY KEY (`id_url_alias`),
  UNIQUE KEY `Индекс 2` (`url`),
  UNIQUE KEY `Индекс 3` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы mycms.url_alias: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `url_alias` DISABLE KEYS */;
INSERT INTO `url_alias` (`id_url_alias`, `url`, `alias`) VALUES
	(1, 'controller=news', 'news'),
	(4, 'news_id=23', 'my23news.html');
/*!40000 ALTER TABLE `url_alias` ENABLE KEYS */;


-- Дамп структуры для таблица mycms.url_alias_admin
DROP TABLE IF EXISTS `url_alias_admin`;
CREATE TABLE IF NOT EXISTS `url_alias_admin` (
  `id_url_alias` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(250) NOT NULL,
  `alias` varchar(250) NOT NULL,
  PRIMARY KEY (`id_url_alias`),
  UNIQUE KEY `Индекс 2` (`url`),
  UNIQUE KEY `Индекс 3` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы mycms.url_alias_admin: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `url_alias_admin` DISABLE KEYS */;
INSERT INTO `url_alias_admin` (`id_url_alias`, `url`, `alias`) VALUES
	(1, 'controller=renews', 'renews');
/*!40000 ALTER TABLE `url_alias_admin` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
